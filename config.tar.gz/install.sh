#!/bin/bash

HOME_DIR=`cd && pwd`
INSTALL_DIR=$HOME_DIR"/nickqi_install"
echo "INSTALL_DIR: "$INSTALL_DIR
mkdir -p $INSTALL_DIR
cd $INSTALL_DIR
if [ ! -d "vim" ]; then
    git clone https://github.com/vim/vim.git
    cd vim
else
    cd vim && git checkout master && git pull
fi
VIM_VERSION=`git branch`
echo "VIM current in branch "$VIM_VERSION
# INSTALL VIM
make && make install
# CHANGE OLD VIM TO vim74 & make current vim newest
mv /usr/bin/vim /usr/bin/vim74
ln -s /usr/local/bin/vim /usr/bin/vim

ln -s ~/.vim/vimrc ~/.vimrc
echo "CONFIG SUCC"
