<?php

    protected $foo;

    public $bar = array( 1, 2, 3 );

    public static $lala = 23;
