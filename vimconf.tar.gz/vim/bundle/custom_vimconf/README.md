custom_vimconf
==============

custom part of vim config
