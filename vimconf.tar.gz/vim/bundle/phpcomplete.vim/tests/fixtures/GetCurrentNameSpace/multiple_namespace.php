<?php
namespace DontFindMe {

}

namespace FindMe {

}
