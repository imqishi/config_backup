<?php
/* @var $bar FooClass */
$bar->

// @var $bar2 FooClass
$bar2->

// @var $bar3 Renamed
$bar3->

$foo_conflicting_sources = Baz::getInstance();
// @var $foo_conflicting_sources Foo
$foo_conflicting_sources->
