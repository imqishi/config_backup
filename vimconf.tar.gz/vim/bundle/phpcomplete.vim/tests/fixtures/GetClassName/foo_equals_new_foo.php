<?php

$foo = new FooClass;
$foo->


$foo = new RenamedFoo;
$foo->
